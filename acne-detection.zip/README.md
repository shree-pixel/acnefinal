# acne-detection
challenges
*insufficient training data: The number of selfie images  is small to train a deep learning model from scratch.
poor quality of images and labels.*

